﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Sample
{
    /// <summary>
    /// Summary description for FileSave
    /// </summary>
    public class FileSave : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            // Get the uploaded image from the Files collection
            var httpPostedFile = HttpContext.Current.Request.Files["UploadedFile"];

            string extension = System.IO.Path.GetExtension(httpPostedFile.FileName);
            if (httpPostedFile != null)
            {
                // Validate the uploaded image(optional)

                // Get the complete file path
             
                //File file = new File() { UserId = Convert.ToInt32(HttpContext.Current.Request.Form["UserId"]) };
                //file.FileName = httpPostedFile.FileName;
              
                //string FileName = file.FileId + extension;
                var fileSavePath = System.IO.Path.Combine(HttpContext.Current.Server.MapPath("~/Files"), httpPostedFile.FileName);
             
                // Save the uploaded file to "UploadedFiles" folder
                httpPostedFile.SaveAs(fileSavePath);

            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}